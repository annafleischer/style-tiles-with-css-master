#Style Tiles with CSS

https://github.com/lasseclaes/style-tiles-with-css
---
forked from and based on Jerad Gallingers work
https://github.com/jeradg/style-tiles-with-scss

http://jeradgallinger.ca - http://codepen.io/jeradg - http://github.com/jeradg

Released under the WTFPL license - http://sam.zoy.org/wtfpl/

Based on Samantha Warren's Style Tiles:
http://styletil.es/ - http://www.alistapart.com/articles/style-tiles-and-how-they-work/