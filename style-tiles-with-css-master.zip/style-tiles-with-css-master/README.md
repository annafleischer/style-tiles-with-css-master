# Style Tiles in HTML, CSS - starting point

This is meant as a starting point for an online style Tile.

You are strongly encouraged to fork this and edit anything you like to make it your own.

Originally forked from https://github.com/jeradg/style-tiles-with-scss, but a lot has been rewritten.
